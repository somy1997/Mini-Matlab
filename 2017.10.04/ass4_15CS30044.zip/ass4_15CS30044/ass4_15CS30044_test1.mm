//normal binary and unary operations
void main()
{
	int a=10,b=11,c,d,e,f=12,g,h,*i;
	Matrix mat[2][3] = {1.0,2.,1.2;3.4,4.3,2.3};
	c=a*b;
	d=a/b;
	e=a%b;
	f=a+b;
	g=a-b;
	a++;
	a--;
	++b;
	--b;
	double z=mat[1][2];
	b=(a+b)*c-d*8;
}


