A compiler for TinyC language (a subset of C).
