//As the matrix initialisation is supported only with floating constants hence modified the test case.

void main(){
		int a=9,b=18;
		double c=7.27,d=c;
		char e=a,f='p';
		Matrix A[3][3]={3.6,3.14,12.1;6.022,2.73,22.4;1.414,9.87,1.602}; // here modified {3.6,a,12.1;b,c,a;c,d,a} to {3.6,3.14,12.1;6.022,2.73,22.4;1.414,9.87,1.602}
		a=-a;
		a-=a;
		a+=a;
		a*=a;
		a/=a;
		a%=a;
		if(a>b)b--;
		else b++;
		a>>=b;
		a|=b;
		return;
}
