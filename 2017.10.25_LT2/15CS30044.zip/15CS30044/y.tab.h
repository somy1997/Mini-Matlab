/* A Bison parser, made by GNU Bison 2.7.  */

/* Bison interface for Yacc-like parsers in C
   
      Copyright (C) 1984, 1989-1990, 2000-2012 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     BREAK = 258,
     CASE = 259,
     CHAR = 260,
     CONTINUE = 261,
     DEFAULT = 262,
     DO = 263,
     DOUBLE = 264,
     ELSE = 265,
     FLOAT = 266,
     FOR = 267,
     GOTO = 268,
     IF = 269,
     INT = 270,
     LONG = 271,
     RETURN = 272,
     SHORT = 273,
     SIGNED = 274,
     SWITCH = 275,
     UNSIGNED = 276,
     VOID = 277,
     WHILE = 278,
     BOOL = 279,
     MATRIX = 280,
     POINTER = 281,
     INCREMENT = 282,
     DECREMENT = 283,
     LEFT_SHIFT = 284,
     RIGHT_SHIFT = 285,
     LESS_EQUALS = 286,
     GREATER_EQUALS = 287,
     EQUALS = 288,
     NOT_EQUALS = 289,
     AND = 290,
     OR = 291,
     MULTIPLY_ASSIGN = 292,
     DIVIDE_ASSIGN = 293,
     MODULO_ASSIGN = 294,
     ADD_ASSIGN = 295,
     SUBTRACT_ASSIGN = 296,
     LEFT_SHIFT_ASSIGN = 297,
     RIGHT_SHIFT_ASSIGN = 298,
     AND_ASSIGN = 299,
     XOR_ASSIGN = 300,
     OR_ASSIGN = 301,
     SINGLE_LINE_COMMENT = 302,
     MULTI_LINE_COMMENT = 303,
     DASH = 304,
     IDENTIFIER = 305,
     INTEGER_CONSTANT = 306,
     FLOATING_CONSTANT = 307,
     CHAR_CONST = 308,
     STRING_LITERAL = 309,
     UNARY = 310
   };
#endif


#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{
/* Line 2058 of yacc.c  */
#line 9 "15CS30044.y"

    basic_value value;
    matrix_row *rowval;
    string *str;
    arglistStr argsl; //to define the argumnets list
    int instr;  // to defin the type used by M->(epsilon)
    expresn expon;   // to define the structure of expression
    list *nextlist;  //to define the nextlist type for N->(epsilon)
    bool isPointer;
    vector< expresn > *symlist;
    char charval; 


/* Line 2058 of yacc.c  */
#line 126 "y.tab.h"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE yylval;

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
