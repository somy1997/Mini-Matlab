
#include "15CS30032_translator.h"


extern int yydebug;
extern char * yytext;
extern int yyparse();
void yyerror(const char *c){
    cout << c <<endl;
}
extern int yylex();

int temp_variable_count = 0;

sym_table * globalSymbolTable = new sym_table();
sym_table * localSymbolTable = new sym_table();
quadList quad;
globalVariables GV;



string i2s(int n);




type_::type_(){}

type_::type_(general_types g,int length , int breadth ){
	gType = g;
	size = 1;
	next = NULL;

	 switch (g)
	{
		case(CHAR_type):
			size = SIZE_OF_CHAR;
			break;
    	case(INT_type):
    		size = SIZE_OF_INT;
    		break;
    	case(DOUBLE_type):
    		size = SIZE_OF_DOUBLE;
    		break;
        case(MATRIX_type):

            this -> length = length;
            this -> breadth = breadth;
            this->size = length*breadth*SIZE_OF_DOUBLE+8;
            break;
        case(_BOOL_type):
            break;
        case(VOID_type):
            size = 0;
        case(PTR_type):
            size = SIZE_OF_PTR;
    	default:
    		break;
    }

}





  type_::type_(type_ & t) {

    type_ * ptr1 = this;
    type_ * ptr2 =  &t;
    ptr1->gType = ptr2->gType;
    ptr1->size = ptr2->gType;
    while(ptr2 != NULL) {
        ptr1->gType = ptr2->gType;
        ptr1->size = ptr2->size;
        ptr1->length = ptr2 -> length;
        ptr1->breadth = ptr2->breadth;
        ptr2 = ptr2->next;
        if(ptr2 == NULL) ptr1->next = NULL;
        else ptr1->next = new type_();
        ptr1 = ptr1->next;
      }
   }


int type_ ::get_Size(){
     switch (gType)
        {
            case(CHAR_type):
                return SIZE_OF_CHAR;
                break;
            case(INT_type):
                return SIZE_OF_INT;
                break;
            case(DOUBLE_type):
                return SIZE_OF_DOUBLE;
                break;
            case(MATRIX_type):
                return length*breadth*SIZE_OF_DOUBLE+8;
                break;
            case(VOID_type):
                return 0;
            case(PTR_type):
                return SIZE_OF_PTR;
            default:
                return 0;
                break;
        }

}


void type_::print() {
    switch(gType) {
        case (INT_type):
            printf("int");
            break;
        case (DOUBLE_type):
            printf("double");
            break;
        case (CHAR_type):
            printf("char");
            break;;
        case (VOID_type):
            printf("void");
            break;
        case (PTR_type):
            printf("ptr(");
            next->print();
            printf(")");
            break;

        case (MATRIX_type):
            printf("Matrix ( %d , %d )",length,breadth);
            break;
        default:
            printf("Error ! Unknown type found !\n");
            exit(-1);
    }
}

bool isSame(type_ * t1, type_ * t2) {
    type_ * ptr1 = t1;
    type_ * ptr2 = t2;
    while(ptr1 != NULL and ptr2 != NULL) {
        if(ptr1->gType != ptr2->gType) return false;
        ptr1 = ptr1->next;
        ptr2 = ptr2->next;
    }
    if(t1->gType == MATRIX_type && t2->gType == MATRIX_type){
        if(t1->length!= t2->length || t1->breadth != t2 -> breadth)return false;
        else
        return true;
    }




    if(ptr1 == NULL && ptr2 == NULL) return true;

    else {
        yyerror("Incompatible types");
        exit(1);
    }
    return false;
}



void convChar2Int(exp_t &e){
    sym_table_entry * new_entry = localSymbolTable->genTemp(new type_(INT_type));
    quad.emit("OP_CHAR_TO_INT",new_entry->name,e.loc->name);
    e.loc = new_entry;
    e.type = new type_(INT_type);


}

void convInt2Double(exp_t &e){
    sym_table_entry * new_entry = localSymbolTable->genTemp(new type_(DOUBLE_type));
    quad.emit("OP_INT_TO_DOUBLE",new_entry->name,e.loc->name);
    e.loc = new_entry;
    e.type = new type_(DOUBLE_type);
}


void convDouble2Int(exp_t &e){
    sym_table_entry * new_entry = localSymbolTable->genTemp(new type_(INT_type));
    quad.emit("OP_DOUBLE_TO_INT",new_entry->name,e.loc->name);
    e.loc = new_entry;
    e.type = new type_(INT_type);
}



void convInt2Char(exp_t &e){
    sym_table_entry * new_entry = localSymbolTable->genTemp(new type_(CHAR_type));
    quad.emit("OP_INT_TO_CHAR",new_entry->name,e.loc->name);
    e.loc = new_entry;
    e.type = new type_(CHAR_type);
}


void backPatch(List  & p, int addr){
    int n = p.list.size(),idx;
    for(int i=0;i<n;i++){
        idx = p.list[i];
        quad.quad_v[idx-100].result = i2s(addr);
    }
}


void convBool2Int(exp_t &e){
   // cout << e.trueList->list[0] <<endl;
    //cout << e.falseList->list[0] <<endl;

    backPatch(*(e.trueList),quad.nextInstr-3);
   // cout << quad.nextInstr-3  <<"called";
    e.loc = localSymbolTable->genTemp(new type_(INT_type));
    e.type = e.loc->type;
    //quad.emit("",e.loc->name,"1");
    quad.quad_v[quad.nextInstr-3-100].setresult(e.loc->name);

    //quad.emit("OP_GO_TO",i2s(quad.nextInstr+2));
    //cout << (e.falseList)->list[0] << quad.nextInstr;
    backPatch(*(e.falseList),quad.nextInstr-1);
    quad.quad_v[quad.nextInstr-1-100].setresult(e.loc->name);


    //cout << quad.quad_v[quad.nextInstr-1].result << endl;
}



bool typeCheck(exp_t &e1, exp_t &e2,bool force,bool isMulti){





    if(e1.type->gType == MATRIX_type && e2.type->gType == MATRIX_type ){
        if(!isMulti){
            return (e1.type->length == e2.type->length)&&(e1.type->breadth == e2.type->breadth);
        }
        else{
            if(e1.type->breadth == e2.type -> length)return true;
            return false;
        }
    }
    else if(e1.type->gType == MATRIX_type || e2.type -> gType == MATRIX_type){
        return false;
    }

    //now from here both types are non-matrices.


    if(isSame(e1.type,e2.type))return true;

    if(!force){
        if(e1.type->gType > e2.type->gType){
            //convert t2 to t1
            if(e1.type ->gType == INT_type && e2.type->gType == _BOOL_type ){
                convBool2Int(e2); //requires extensive backpatching
                return true;
            }
            else if(e1.type -> gType == INT_type && e2.type -> gType == CHAR_type){
                convChar2Int(e2);
                return true;
            }
            else if(e1.type ->gType == DOUBLE_type && e2.type -> gType == INT_type){
                convInt2Double(e2);
                return true;
            }
            return false;

        }
        else{
            if(e2.type ->gType == INT_type && e1.type->gType == _BOOL_type ){
                convBool2Int(e1); //requires extensive backpatching
                return true;
            }
            else if(e2.type -> gType == INT_type && e1.type -> gType == CHAR_type){
                convChar2Int(e1);
                return true;
            }
            else if(e2.type ->gType == DOUBLE_type && e1.type -> gType == INT_type){
                convInt2Double(e1);
                return true;
            }
            return false;
        }
    }


    else{
        if(e1.type ->gType == INT_type && e2.type->gType == _BOOL_type ){
                convBool2Int(e2); //requires extensive backpatching
                return true;
            }
            else if(e1.type -> gType == INT_type && e2.type -> gType == CHAR_type){
                convChar2Int(e2);
                return true;
            }
            else if(e1.type ->gType == DOUBLE_type && e2.type -> gType == INT_type){
                convInt2Double(e2);
                return true;
            }

            else{
                if(e1.type ->gType == INT_type && e2.type -> gType == DOUBLE_type){
                    convDouble2Int(e2);
                    return true;
                }
                if(e1.type ->gType == CHAR_type && e2.type -> gType == INT_type){
                    convInt2Char(e2);
                    return true;
                }


            }


            return false;
    }

}




sym_table_entry::sym_table_entry(){
	nested_table = NULL;
	wasInitialized = false;
    num_params = 0;

}

void sym_table_entry::print(){

    printf("\t\t%s\t\t",name.c_str());
    if(wasInitialized) {
        switch(type->gType) {
            case (INT_type):
                printf("%d\t\t", init.val_int);
                break;
            case (CHAR_type):
                printf("%c\t\t", init.val_char);
                break;
            case (DOUBLE_type):
                printf("%lf\t\t", init.val_double);
                break;
            case (MATRIX_type):
                {
                    cout <<"{";
                    for(int i=0;i<(*(init.val_matrix)).size()-1;i++){
                        cout << (*(init.val_matrix))[i] <<", ";
                    }
                    cout << (*(init.val_matrix))[(*(init.val_matrix)).size()-1];
                    cout <<"}\t\t";
                    break;
                }
            default:
                printf("Invalid Type");
        }
    }
    else printf(" NULL\t\t");
    printf("%d\t\t", this->size);
    printf("%d\t\t", this->offset);

    if(nested_table != NULL) printf("%s\t\t",name.c_str());
    else printf("%s\t\t", "NULL");
    type->print();
    printf("\t\t%d\t\t",num_params);

}


sym_table::sym_table(){
	offset=0;
}



bool sym_table::isPresent(string s){
	for(int i = 0; i < entries.size();i++){
		if(entries[i]->name==s)return true;
	}
	return false;
}






sym_table_entry * sym_table::lookup(string s){
	for(int i = 0; i < entries.size();i++){
		if(entries[i]->name==s)return entries[i];
	}
	entries.push_back(new sym_table_entry());
	entries[entries.size()-1]->name = s;
	return entries[entries.size()-1];
}



sym_table_entry * sym_table ::  genTemp(type_ *type){
	sym_table_entry * temporary = new sym_table_entry();
   //cout<<temp_variable_count <<endl;

    temporary -> name = "t"+i2s(temp_variable_count);
    //cout << temporary -> name;
	temp_variable_count=temp_variable_count+1;

    temporary -> type = type;

	int curSz = 0;
    switch(type->gType) {
        case (INT_type):
            curSz = SIZE_OF_INT;
            break;
        case (CHAR_type):
            curSz = SIZE_OF_CHAR;
            break;
        case (DOUBLE_type):
            curSz = SIZE_OF_DOUBLE;
            break;
        case (PTR_type):
            curSz = SIZE_OF_PTR;
            break;
        case (MATRIX_type):
            curSz = type->size;
            break;
        default:
            curSz = 0;
		}
	temporary->offset = offset;
	temporary->size = curSz;

	entries.push_back(temporary);
	offset += curSz;

    return temporary;
}


void sym_table::update(sym_table_entry *s, type_ *t, int sz)
{
	s->type = t;
    s->size = sz;
    s->offset = offset;
	offset += s->size;
}



void sym_table::update(sym_table_entry * s, initialVal init)
{
	s->init = init;
	s->wasInitialized = true;
}

void sym_table::print(){
     if(name=="")
        printf("printing global symbol table ->\n");
     else
        printf("printing symbol table for function %s ->\n",name.c_str());
     printf("\t\tName\t\tInitVal\t\tSize\t\tOffset\t\tNested\t\tType\t\tNumParams\n");
	for(int i=0;i<entries.size();i++)
	{
		entries[i]->print();
		cout << "\n";
	}
}


quadEntry :: quadEntry(){

}


void quadEntry :: setop(string _op){
	op = _op;
}



void quadEntry :: setresult(string _result){
	result = _result;
}



void quadEntry :: setarg1(string _arg1){
	arg1 = _arg1;
}


void quadEntry :: setarg2(string _arg2){
	arg2 = _arg2;
}


void quadEntry::print() {

    	if (op == "OP_MULT")
    		printf("%s = %s * %s \n",result.c_str(),arg1.c_str(),arg2.c_str());

    	else if (op =="OP_PARAM")
    		printf("param %s\n",result.c_str());

    	else if (op =="OP_FUNC_CALL")
    		printf("%s = call %s,%s\n",result.c_str(),arg1.c_str(),arg2.c_str());

    	else if (op == "OP_R_INDEX")
    		printf("%s = %s[%s]\n",result.c_str(),arg1.c_str(),arg2.c_str());
    	else if (op == "OP_L_INDEX")
    		printf("%s[%s] = %s\n",result.c_str(),arg1.c_str(),arg2.c_str());

    	else if (op == "OP_ADD")
    		printf("%s = %s + %s\n",result.c_str(),arg1.c_str(),arg2.c_str());

    	else if (op == "OP_SUB")
    		printf( "%s = %s - %s\n",result.c_str(),arg1.c_str(),arg2.c_str());

    	else if (op == "OP_TRANSPOSE")
    		printf("%s = (transpose)%s\n",result.c_str(),arg1.c_str());
    	else if (op == "")
            printf("%s = %s\n",result.c_str(),arg1.c_str());
    	else if(op == "OP_ADDRESS")
            printf("%s = &%s\n",result.c_str(),arg1.c_str());
        else if(op == "OP_DEREF")
            printf("%s = *%s\n",result.c_str(),arg1.c_str());
        else if(op=="OP_NEG")
            printf("%s = -%s\n",result.c_str(),arg1.c_str());
        else if(op == "OP_INT_TO_CHAR")
            printf("%s = (char)%s\n",result.c_str(),arg1.c_str());
        else if(op == "OP_CHAR_TO_INT")
            printf("%s = (int)%s\n",result.c_str(),arg1.c_str());
        else if(op == "OP_INT_TO_DOUBLE")
            printf("%s = (double)%s\n",result.c_str(),arg1.c_str());
        else if(op == "OP_DOUBLE_TO_INT")
            printf("%s = (int)%s\n",result.c_str(),arg1.c_str());
        else if(op == "OP_DIV")
            printf("%s = %s/%s\n",result.c_str(),arg1.c_str(),arg2.c_str());
        else if(op == "OP_MOD")
            printf("%s = %s mod %s\n",result.c_str(),arg1.c_str(),arg2.c_str());
        else if(op=="OP_LEFT_SHIFT")
            printf("%s = %s << %s\n",result.c_str(),arg1.c_str(),arg2.c_str());
        else if(op=="OP_RIGHT_SHIFT")
            printf("%s = %s >> %s\n",result.c_str(),arg1.c_str(),arg2.c_str());
        else if(op == "OP_LT")
            printf("if %s < %s goto %s\n",arg1.c_str(),arg2.c_str(),result.c_str());
        else if(op == "OP_GT")
            printf("if %s > %s goto %s\n",arg1.c_str(),arg2.c_str(),result.c_str());
        else if(op == "OP_LTE")
            printf("if %s <= %s goto %s\n",arg1.c_str(),arg2.c_str(),result.c_str());
        else if(op == "OP_GTE")
            printf("if %s >= %s goto %s\n",arg1.c_str(),arg2.c_str(),result.c_str());
        else if(op == "OP_GO_TO")
            printf("goto %s\n",result.c_str());
        else if(op == "OP_NEQU")
            printf("if %s != %s goto %s\n",arg1.c_str(),arg2.c_str(),result.c_str());
        else if(op == "OP_EQU")
            printf("if %s == %s goto %s\n",arg1.c_str(),arg2.c_str(),result.c_str());
        else if(op=="OP_BW_AND")
            printf("%s = %s & %s\n",result.c_str(),arg1.c_str(),arg2.c_str());
        else if(op=="OP_BW_XOR")
            printf("%s = %s ^ %s\n",result.c_str(),arg1.c_str(),arg2.c_str());
         else if(op=="OP_BW_OR")
            printf("%s = %s | %s\n",result.c_str(),arg1.c_str(),arg2.c_str());
        else if(op=="OP_L_DEREF")
            printf("*%s = %s  \n",result.c_str(),arg1.c_str());
        else if(op=="OP_RET")
            printf("return %s\n",result.c_str());
        else if(op=="OP_LAB")
            printf("function %s :\n",result.c_str());
        else if(op=="OP_LAB_END"){
            printf("\n");
        }

        else
    		printf("Invalid OP-CODE %s",op.c_str());





}

void quadList::emit(string op, string result , string arg1, string arg2 ){
	quadEntry temp = quadEntry();
	temp.setop(op);
	temp.setresult(result);
	temp.setarg1(arg1);
	temp.setarg2(arg2);
	quad_v.push_back(temp);
	nextInstr++;

}



void quadList::emit(string op, string result,  string arg1){
	quadEntry temp = quadEntry();
	temp.setop(op);
	temp.setresult(result);
	temp.setarg1(arg1);
	quad_v.push_back(temp);
	nextInstr++;
}


void quadList::emit(string op,string result){
	quadEntry temp = quadEntry();
	temp.setop(op);
	//temp.setresult(result);
	temp.setresult(result);
	quad_v.push_back(temp);
	nextInstr++;
}



void quadList::print(){
	for(int i=0;i<quad_v.size();i++){
		string A = i2s(i+100)+":  ";
        printf("%s",A.c_str());
        quad_v[i].print();
	}

}

string i2s(int n){
	char tmp[10];
    sprintf(tmp, "%d", n);
	return tmp;
}

bool checkParams(exp_t  e, vector <exp_t * > * v){
    int n = e.loc->num_params;
    if((*v).size()!=n)return false;
    for(int i=0;i<n;i++){
        exp_t e1 = exp_t();
        e1.type = (e.loc->nested_table->entries)[i]->type;
        bool a = typeCheck(e1,*((*v)[i]),true,false);


        if(!a){
            return false;
        }
    }
    return true;
}


List :: List(){

}


List :: List(int idx){
    list.push_back(idx);
}


void List :: clear(){
    list.clear();
}

void List :: print(){
    int n = list.size();
    for(int i=0;i<n;i++){
        cout << list[i] <<" ";
    }
    cout << endl;
}


List * mergeList(List *l1,List *l2){

    List * x = new List();
    x->list = (*l1).list;
    x->list.insert(x->list.end(),(*l2).list.begin(),(*l2).list.end());
    return x;
}




int main(){
    quad.nextInstr = 100;


    yyparse();

    quad.print();

}
