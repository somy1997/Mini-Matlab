#ifndef __TRANSLATOR_H
#define __TRANSLATOR_H

#include <iostream>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <assert.h>
#include <string>



using namespace std;

using namespace std;


#define SIZE_OF_BOOL    1
#define SIZE_OF_INT     4
#define SIZE_OF_DOUBLE  8
#define SIZE_OF_CHAR    1
#define SIZE_OF_VOID    0
#define SIZE_OF_PTR     4
#define SIZE_OF_FUNC    0

struct sym_table_entry;
struct sym_table;
struct List;
struct exp_t;
struct type_;
struct globalVariables;


//basic types available in minimatlab

typedef enum{
    _BOOL_type, //implicit bool type
    CHAR_type,  
    INT_type,
    DOUBLE_type,
    VOID_type, //void type(used in function declarations)
    PTR_type, //pointer type
    MATRIX_type,
} general_types;




//general structure to store all possible types
struct type_{
	general_types gType;

	int size; //size of the type


	int length;  //for matrices

	int breadth; //for matrices

	type_ *next; //used in the case when gType is PTR_type

	void print();

	type_();

	

	type_(type_ &t); //copy-contrsuctor

    type_(general_types g,int length =0 , int breadth =0) ;//for matrices

    int get_Size();

    
};


bool isSame(type_ *t1, type_ *t2);  //function used to return whether the types of the 








//A structure that stores global variables.
struct globalVariables{
   type_ * type;            //used in declaration of variables and functions to propogate the type from type-specifier to declarator
   int width ;
   int old_width;
   int length;             //used to propogate the length when matrices are declared using the init-declarator grammar rule.
   int breadth;            //used to propogate the length when matrices are declared using the init-declarator grammar rule.
   bool _switch;
};


//union for storing initial values in symbol table
union initialVal{
	int val_int;                //for int type
	double val_double;          //for flaot types
	char val_char;              //for char types
	vector  <double> *val_matrix; //for matrix types
};
//pointers are used because elements with constructors are not allowed in the union.




//structure for the symbol table
struct sym_table{
	int offset;                                             //offset to be assigned to the next symbol table entry
	sym_table_entry * parent;                               //used in case of local symbol tables for functions - parent points to the entry of the function in the global symbol table
    vector <sym_table_entry*> entries;                      //vector of symbol table entries, this is where the symbol table entries are actually stored                    
	bool isPresent(string s);                               //return true is s is the name of an entry in the symbol table
	sym_table_entry* lookup(string name);                   // if argument-name is present in the table return its reference, else create a new entry with the name as argument-name
	sym_table_entry* genTemp(type_ *type);                  // generate a symbol table entry for a new temporary of type argument-type
	void update(sym_table_entry *s, type_ *t, int sz);      //update the symbol table entry s with type t and set its size as z
	void update(sym_table_entry * s, initialVal init);      // set the symbol table entry s's initital value as init
    string name;                                            //name of the symbol table
	sym_table();                                            //return a symbol table
	
	void print();                                           //print the symbol table               
	




};


//structure for the symbol table entry
struct sym_table_entry{
	string name;                                           //name of the entry
	type_ * type;                                          //type of the entry
	bool wasInitialized;                                   //if true then the init value was set by the parser 
	initialVal init;                                       //stores the initial value
	int offset;                                            //stores the offset of the symbol table entry
    int size;                                              //stores the size of the type
    int num_params;                                        //if name is a function, then this stores the number of parameters of the funcion
	sym_table * nested_table;                              //if name is a function, this stores a pointer to the nested table 

	sym_table_entry();

	void print();

};









struct quadEntry{
	string op,result,arg1,arg2;                     //op_code,result,arguments are stored as strings
	
	
	quadEntry();                      //return new quadEntry

    void setop(string _op);           //set the strings, these functions are called by the quadList function emit.

    void setresult(string _result);     //setter for result
 
    void setarg1(string _arg1);                 //setter for arg1

    void setarg2(string _arg2);               //setter for arg2

    void print();          //print quadcode

};




struct quadList {
                                                                               


    int nextInstr;                                                             // index of next quad to be generated

    vector <quadEntry> quad_v;                                                 //stores the list of quad entries
    void emit(string op, string result , string arg1, string arg2 );           //result = arg1 op arg2
    void emit(string op, string result,  string arg1);                         //result = op arg1 if op=="", then COPY
    void emit(string op,string result);                                        //result = arg1
    void print();

};






// Structure used to represent nextList, trueList, falseList
struct List {
    
    vector <int> list;           //stores the indices of quad instructions

    List(int idx);               //creates a new list with first entry as idx

    List();                      //creates a new empty list

    void clear();               //empties a list

    void print();               //prints a list

};


//merge two lists
List * mergeList(List * l1, List * l2);








// attribute for expression type non terminals.
// Always store elements in union types that do not have constructors.

struct exp_t {


    // true list
    List * trueList;
    
    // false list
    List * falseList;
    
    // pointer to entry in symbol table
    sym_table_entry * loc;
    
    // store array name -> this is used when isArrayType is true.
    string * array_name;
    
    // pointer of type
    type_ * type;
    
    // flag to store if this is of matrix type and needs to be dereferenced
    bool isMatrixType;
    
    // flag to store if this is of pointer type and needs to be dereferenced
    bool isPtrType;
    
    //flag to store if the expression is a constant
    bool isConstant;
    
  
    

    //number of times pointer is dereferenced.
    int num_deref;

  
    //stores pointers to symbol temporaries that store an initial value of a matrix
    vector <sym_table_entry*>  * matrix_init_values;

    //used specifically for matrices, if true then the wasInitialized attribute for every symbol table entry pointed to by matrix_init_values is true; 
    bool wasInitialized;
    
};



// attribute for declaration type non terminals
struct dec_t {
    type_ * type;
    int width;
};







//convert an integer to string




string i2s(int n); //function to convert interger to string




//type conversion global functions

void convInt2Double(exp_t & e); 

void convDouble2Int(exp_t & e); 

void convChar2Int(exp_t & e); 

void convInt2Char(exp_t & e); 

 


void backPatch(List  & p, int addr);

bool typeCheck(exp_t &e1, exp_t &e2,bool force,bool isMulti);

bool checkParams(exp_t  e, vector <exp_t * > * v); //


extern sym_table * globalSymbolTable;
extern sym_table * localSymbolTable;
extern quadList quad; 
extern globalVariables GV;

#endif



