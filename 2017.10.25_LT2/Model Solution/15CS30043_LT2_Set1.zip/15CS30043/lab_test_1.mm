//My Compiler does not support dynamic initialization : {3.6,a,12.1;b,c,a;c,d,a} The values inside the curly braces must be double or int hence the modified test file
void main(){
	int a=9,b=18;
	double c=7.27,d=c;
	char e=a,f='p';
	Matrix A[3][3] = {3.6,9,12.1;18,7.27,9,7.27,7.27,9}; 			 
	a=-a;
	a-=a;
	a+=a;
	a*=a;
	a/=a;
	a%=a;
	if(a>b)b--;
	else b++;
	a <<= b;
	a &=b;
	return;
}
