//hadling static variables
static int doctor=5;
int nurse=6;
int main()
{
	int i;
	i=nurse+2; //6+2
	printi(i);
	prints("\n");
	nurse=5;
	i=nurse;   //5
	printi(i);
	prints("\n");
	return 0;
}
